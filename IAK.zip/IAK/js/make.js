$(document).ready(function(){
  $(#intro).hover(function(){
    $(this).html('Helloooooooo');
  });
  $(.panel).html('MMMMMMMMMMMMmmmmm');
});
